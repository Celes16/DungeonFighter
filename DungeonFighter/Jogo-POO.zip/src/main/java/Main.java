
import javax.swing.JFrame;

public class Main {
    public static void main(String[] args) {
        DungeonMenuApp dungeonMenuApp = new DungeonMenuApp();
        dungeonMenuApp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        dungeonMenuApp.main(args); 
    }
}

